package com.htz.controller;

import com.htz.service.DoctorService;
import com.htz.service.PatientService;
import com.htz.service.ProposalService;
import com.htz.vo.Patients;
import com.htz.vo.Proposals;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/27 1:32 PM
 * @Version 1.0
 */

@Controller
public class HomeController {
    @Autowired
    private PatientService patientService;
    @Autowired
    private DoctorService doctorService;
    @Autowired
    private ProposalService proposalService;

    @RequestMapping("/home")
    public String home(){
        return "Home";
    }

    /**
     * 患者可以登录
     * @return
     */
    @RequestMapping("/toPatientLogin")
    public String toPatientLogin(){
        return "patientLoginPage";
    }
    @RequestMapping("/patientLogin")
    public String patientLogin(String pid, String password, ModelMap modelMap){
        if (patientService.getPatientById(pid)==null){
            System.out.println("pid is null");
            return "redirect:toPatientLogin";
        }else{
            System.out.println("pid is" + pid);
            if(patientService.getPatientById(pid).getPassword().equals(password)){
                Patients patients = patientService.getPatientById(pid);
                modelMap.put("patients",patients);
                //只能返回一个proposal，但我需要返回该病人所有的proposals
                List<Proposals> proposals1 = proposalService.list();
                List<Proposals> proposals = new ArrayList<Proposals>();
                for (Proposals p :proposals1) {
                    if(p.getPid().equals(pid)){
                        proposals.add(p);
                    }
                }
                modelMap.put("proposals",proposals);
                return "listPatientInfo";
            }else{
                System.out.println("pid:"+pid+" but pwd is wrong:"+password);
                return "redirect:toPatientLogin";
            }
        }
    }
    /**
     * 医生可以登录
     * @return
     */
    @RequestMapping("/toDoctorLogin")
    public String toDoctorLogin(){
        return "doctorLoginPage";
    }
    @RequestMapping("/doctorLogin")
    public String doctorLogin(String did, String password, ModelMap modelMap){
        Integer dd = Integer.valueOf(did);
        if (doctorService.getDoctorByDid(dd)==null){
            System.out.println("did is null");
            return "redirect:toDoctorLogin";
        }else{
            System.out.println("did is" + dd);
            System.out.println("pwd is" + password);
            System.out.println("pwd in db is" + doctorService.getDoctorByDid(dd).getDpassword());
            if(doctorService.getDoctorByDid(dd).getDpassword().equals(password)){
                List<Patients> patients = patientService.list();
                modelMap.put("patients",patients);
                return "listPatients";
            }else{
                System.out.println("did:"+dd+" but pwd is wrong:"+password);
                return "redirect:toDoctorLogin";
            }
        }
    }

}
