package com.htz.controller;

import com.htz.service.PfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/6/4 8:15 PM
 * @Version 1.0
 */

@Controller
public class PfileController {
    @Autowired
    private PfileService pfileService;
    @RequestMapping("/pfile")
    private void pfile() throws IOException {
         pfileService.faceRecognition();
    }
}
