package com.htz.controller;

import com.htz.service.*;
import com.htz.vo.Datas;
import com.htz.vo.Equation;
import com.htz.vo.Patients;
import com.htz.vo.Proposals;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;
import java.util.*;
import java.util.List;

/**
 * description: dmp-core
 * 用于医生浏览病人，展示出病人列表
 * 对于每个病人，要求可以查看病人信息和诊疗方案
 * 每个病人可以添加新的方案，也可以修改诊疗方案
 * @Author htz
 * @Date 2022/5/15 9:20 AM
 * @Version 1.0
 */

@Controller
public class DoctorController {
    @Autowired
    private DoctorService doctorService;
    @Autowired
    private PatientService patientService;
    @Autowired
    private ProposalService proposalService;
    @Autowired
    private DataService dataService;
    @Autowired
    private EquationService equationService;
    @Autowired
    private PfileService pfileService;

    private String dataPid;


    /**
     * listPatients:
     * 用于医生浏览病人，展示出病人列表
     * @param modelMap
     * @return
     */
    @RequestMapping("/listPatients")
    public String listPatients(ModelMap modelMap){
        List<Patients> patients = patientService.list();
        modelMap.put("patients",patients);
        return "listPatients";
    }

    @RequestMapping("/delete")
    public String delete(Integer did){
        doctorService.delete(did);
        return "redirect:/listPatients";
    }

    /**
     * 医生在后台添加病人信息--用于练习
     * @return
     */
    @RequestMapping("/addAPatientForm")
    public String addAPatientForm(){
        return "addAPatientForm";
    }

    @RequestMapping("/add")
    public String add(Patients patient){
        if(patientService.getPatientById(patient.getPid())!=null){
            System.out.println("用户已存在");
        }else {
            patient.setPassword("1234");
            patientService.add(patient);
        }
        return "redirect:/listPatients";
    }

    /**
     * 详细信息：医生可以直接查看病人的详细信息ok，可以修改病历信息ok
     * 查看病人的历史方案ok
     * @return
     */
    @RequestMapping("/patientDetails")
    public String patientDetails(String pid,ModelMap modelMap){

        Patients patients = patientService.getPatientById(pid);
        modelMap.put("patients",patients);
        //只能返回一个proposal，但我需要返回该病人所有的proposals
        List<Proposals> proposalsAll = proposalService.list();
        List<Proposals> proposals = new ArrayList<Proposals>();
        for (Proposals p :proposalsAll) {
            if(p.getPid().equals(pid)){
                proposals.add(p);
            }
        }
        System.out.println("已经Equation:"+pid);
        List<Equation> equations = equationService.getEquationsByPid(pid);

        modelMap.put("proposals",proposals);
        modelMap.put("equations",equations);
        dataPid = pid;
        return "listAPatient";
    }

    @RequestMapping("/updatePatient")
    public String updatePatient(Patients patients){
        String oldHistory = patientService.getPatientById(patients.getPid()).getHistory();
        String newHistory = patients.getHistory();
        patients.setHistory(oldHistory+"/n"+newHistory);
        patientService.update(patients);
        return "redirect:/listPatients";
    }

    /**
     * 医生可以对病人新建治疗历史方案
     * @param pid
     * @return
     */
    @RequestMapping("/addProposalForm")
    public String addProposalForm(String pid,ModelMap modelMap){

       Patients patients = patientService.getPatientById(pid);
       modelMap.put("patients",patients);
       return "addProposalForm";
    }

    @RequestMapping("/addProposal")
    public String addProposal(String pid, String pname, Integer did, String createdt, String details, ModelMap modelMap){
        System.out.println("pid: "+ pid);
        System.out.println("pname: "+ pname);
        System.out.println("did:"+ did);
        Proposals proposals = new Proposals(null,pname,pid,did,createdt,details);
        proposalService.add(proposals);

        Patients patients = patientService.getPatientById(pid);
        modelMap.put("patients",patients);

        return "redirect:/listPatients";
    }


    /**
     * 需要医生可以看到病人的历史数据
     * 拿到病人的id，去查找病人的所有data 和病人预测的参数
     * @param pid
     */
    @ResponseBody
    @RequestMapping("getDataByPid")
    public List<Datas> getDataByPid(String pid) throws IOException {
        pfileService.faceRecognition();
        List<Datas> datas = dataService.getDataByPid(pid);
        System.out.println("已经pid:"+pid);
        return datas;
    }
    @ResponseBody
    @RequestMapping("getEquationByPid")
    public List<Equation> getEquationByPid(String pid) throws IOException {
        pfileService.faceRecognition();
        System.out.println("已经Equation:"+pid);
        List<Equation> equations = equationService.getEquationsByPid(pid);
        return equations;
    }


}
