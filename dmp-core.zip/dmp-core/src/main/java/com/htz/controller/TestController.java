package com.htz.controller;

import com.htz.service.DataService;
import com.htz.vo.Datas;
import com.htz.vo.Emp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * description: 这个controller作为测试，尝试各个方法
 *
 * @Author htz
 * @Date 2022/5/14 11:02 AM
 * @Version 1.0
 */

@Controller
public class TestController {

    @Autowired
    private DataService dataService;

    private String pid="1";

    @ResponseBody
    @RequestMapping("/sayHello")
    public Map<String,String> sayHello(){
        Map<String,String> emps = new HashMap<>();
        emps.put("1","one");
        emps.put("2","two");
        emps.put("3","three");
        return emps;
    }

    @RequestMapping("/list")
    public String list(ModelMap modelMap){
        Map<String,String> emps = new HashMap<>();

        emps.put("one","first");
        emps.put("two","second");
        emps.put("three","third");

        modelMap.put("emps",emps);

        return "list";
    }
    @RequestMapping("/listEmp")
    public String listEmp(ModelMap modelMap){
        List<Emp> emps = new ArrayList<>();

        emps.add(new Emp(1,"htz","18715556858","ande"));
        emps.add(new Emp(2,"pyy","18715556859","hk"));
        emps.add(new Emp(3,"lx","18715556850","sh"));

        modelMap.put("emps",emps);
        return "listEmp";
    }

    @RequestMapping( "/show")
    @ResponseBody
//    public List<Datas> findById() {
        public List<Datas> findById(Model model) {
        List<Datas> users = dataService.getDataByPid("1");
//        System.err.println(users.toString());
        return users;
    }

    //展示折线图
    @RequestMapping( "/showline")
    public String show4() {
        return "listEmp";
    }

}
