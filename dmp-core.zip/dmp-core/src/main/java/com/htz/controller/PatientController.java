package com.htz.controller;

import com.htz.service.DoctorService;
import com.htz.service.PatientService;
import com.htz.service.ProposalService;
import com.htz.vo.Doctors;
import com.htz.vo.Patients;
import com.htz.vo.Proposals;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/15 9:21 AM
 * @Version 1.0
 */

@Controller
public class PatientController {

    @Autowired
    private PatientService patientService;
    @Autowired
    private ProposalService proposalService;

    /**
     * 该方法用户病人可以查看自己的信息，查看自己的病历
     * 查看自己的历史治疗方案
     * @param pid
     * @param modelMap
     * @param modelMap2
     * @return
     */
    @RequestMapping("/patientInfo")
    public String patientInfo(String pid,ModelMap modelMap,ModelMap modelMap2){
        Patients patients = patientService.getPatientById(pid);
        modelMap.put("patients",patients);
        //只能返回一个proposal，但我需要返回该病人所有的proposals
        List<Proposals> proposals1 = proposalService.list();
        List<Proposals> proposals = new ArrayList<Proposals>();
        for (Proposals p :proposals1) {
            if(p.getPid().equals(pid)){
                proposals.add(p);
            }
        }
        modelMap.put("proposals",proposals);
//        dataPid = pid;
        return "listPatientInfo";
    }
}
