package com.htz.service;

import com.htz.mapper.PatientMapper;
import com.htz.vo.Patients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/15 10:36 AM
 * @Version 1.0
 */

@Service
public class PatientService {

    @Autowired
    private PatientMapper patientMapper;

    public List<Patients> list() {
        return patientMapper.list();
    }
    public Patients getPatientById(String pid) {
        return patientMapper.getPatientById(pid);
    }

    public void add(Patients patient) {
        patientMapper.add(patient);
    }



    public void update(Patients patients) {
        patientMapper.update(patients);
    }
}
