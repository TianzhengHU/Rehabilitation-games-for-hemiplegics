package com.htz.service;

import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.util.Arrays;


/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/6/4 8:17 PM
 * @Version 1.0
 */

@Service
public class PfileService {
    public void faceRecognition() throws IOException{
        //前面一半是本地环境下的python的启动文件地址，后面一半是要执行的python脚本地址
        String[] arguments = new String[] {
                "/Users/htzzzzzzz/anaconda3/envs/tensorflow/bin/python",//python执行器的位置
                "/Users/htzzzzzzz/PycharmProjects/2020-11-9/Piantan.py"//python文件的绝对路径
//                "/root/anaconda3/envs/htzenvs/bin/python",//python执行器的位置
//                "/root/Piantan.py"
        };
        Process proc;
        try {
            proc = Runtime.getRuntime().exec(arguments);// 执行py文件//1
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println(e);
        }

    }
}

//1
//用输入输出流来截取结果
//            FileInputStream errorStream = (FileInputStream)proc.getErrorStream();
//            InputStreamReader isr = new InputStreamReader(errorStream,"gbk");//读取
//            System.out.println(isr.getEncoding());
//            BufferedReader in = new BufferedReader(isr);//缓冲
//            String line = null;
//            while ((line = in.readLine()) != null) {
//                System.out.println(line);
//            }
//            in.close();
//            //waitFor是用来显示脚本是否运行成功，1表示失败，0表示成功，还有其他的表示其他错误
//            int re = proc.waitFor();
//            System.out.println(re);

//        String[] arguments = new String[] {
//        "E:\\anaconda3\\python.exe",
//        "D:\\python\\Tensorflow\\Face_recognition\\Face_recognition\\demo1.py"};

//        String[] arguments = new String[] {
//        "C:\\Program Files (x86)\\Microsoft Visual Studio\\Shared\\Python36_64\\python.exe",
//        "D:\\python\\Tensorflow\\Face_recognition\\Face_recognition\\demo1.py"
//        };