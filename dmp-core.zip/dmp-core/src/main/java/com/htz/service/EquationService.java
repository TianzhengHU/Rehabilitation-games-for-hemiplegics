package com.htz.service;

import com.htz.mapper.EquationMapper;
import com.htz.vo.Equation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/31 4:55 PM
 * @Version 1.0
 */

@Service
public class EquationService {

    @Autowired
    private EquationMapper equationMapper;


//    public List<Equation> list() {
//        return equationMapper.list();
//    }

    public List<Equation> getEquationsByPid(String pid) {
        return equationMapper.getEquationsByPid(pid);
    }
}
