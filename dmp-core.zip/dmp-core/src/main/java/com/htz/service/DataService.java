package com.htz.service;

import com.htz.mapper.DataMapper;
import com.htz.vo.Datas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/16 3:49 PM
 * @Version 1.0
 */

@Service
public class DataService {

    @Autowired
    private DataMapper dataMapper;

    public List<Datas> list() {
        return dataMapper.list();
    }

    public List<Datas> getDataByPid(String dataPid) {
        return dataMapper.getDataByPid(dataPid);
    }
}
