package com.htz.service;

import com.htz.mapper.DoctorMapper;
import com.htz.vo.Doctors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/15 9:25 AM
 * @Version 1.0
 */

@Service
public class DoctorService {
    @Autowired
    private DoctorMapper doctorMapper;
    public List<Doctors> list() {
        return doctorMapper.list();
    }

    public void delete(Integer did) {
        doctorMapper.delete(did);
    }
    public Doctors getDoctorByDid(Integer did) {
        return doctorMapper.getDoctorByDid(did);
    }
}
