package com.htz.service;

import com.htz.mapper.ProposalMapper;
import com.htz.vo.Proposals;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/17 3:55 PM
 * @Version 1.0
 */

@Service
public class ProposalService {
    @Autowired
    private ProposalMapper proposalMapper;

    public Proposals getProposalByPid(String pid) {
        return proposalMapper.getProposalByPid(pid);
    }

    public void add(Proposals proposals) {
        proposalMapper.add(proposals);
    }

    public List<Proposals> list() {
        return  proposalMapper.list();
    }
}
