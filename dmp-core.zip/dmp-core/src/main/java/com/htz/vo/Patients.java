package com.htz.vo;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/15 10:34 AM
 * @Version 1.0
 */


public class Patients {
    private String pid;
    private String pname;
    private Integer sex;
    private Integer age;
    private String mobile;
    private String password;
    private String history;

    public Patients() {
    }

    public Patients(String pid, String pname, Integer sex, Integer age, String mobile, String password, String history) {
        this.pid = pid;
        this.pname = pname;
        this.sex = sex;
        this.age = age;
        this.mobile = mobile;
        this.password = password;
        this.history = history;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }
}
