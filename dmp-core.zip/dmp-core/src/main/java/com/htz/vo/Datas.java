package com.htz.vo;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/16 4:45 PM
 * @Version 1.0
 */


public class Datas {
    private Integer Did;
    private String Pid;
    private String Pname;
    private double Time1;
    private double H;
    private double M;
    private double L;
    private double fastTime;
    private double Total;
    private double Time2;
    private double N;
    private double Acc;

    public Datas() {
    }

    public Datas(Integer did, String pid, String pname, double time1, double h, double m, double l, double fastTime, double total, double time2, double n, double acc) {
        Did = did;
        Pid = pid;
        Pname = pname;
        Time1 = time1;
        H = h;
        M = m;
        L = l;
        this.fastTime = fastTime;
        Total = total;
        Time2 = time2;
        N = n;
        Acc = acc;
    }

    public Integer getDid() {
        return Did;
    }

    public void setDid(Integer did) {
        Did = did;
    }

    public String getPid() {
        return Pid;
    }

    public void setPid(String pid) {
        Pid = pid;
    }

    public String getPname() {
        return Pname;
    }

    public void setPname(String pname) {
        Pname = pname;
    }

    public double getTime1() {
        return Time1;
    }

    public void setTime1(double time1) {
        Time1 = time1;
    }

    public double getH() {
        return H;
    }

    public void setH(Integer h) {
        H = h;
    }

    public double getM() {
        return M;
    }

    public void setM(Integer m) {
        M = m;
    }

    public double getL() {
        return L;
    }

    public void setL(Integer l) {
        L = l;
    }

    public double getFastTime() {
        return fastTime;
    }

    public void setFastTime(double fastTime) {
        this.fastTime = fastTime;
    }

    public double getTotal() {
        return Total;
    }

    public void setTotal(double total) {
        Total = total;
    }

    public double getTime2() {
        return Time2;
    }

    public void setTime2(double time2) {
        Time2 = time2;
    }

    public double getN() {
        return N;
    }

    public void setN(double n) {
        N = n;
    }

    public double getAcc() {
        return Acc;
    }

    public void setAcc(double acc) {
        Acc = acc;
    }
}
