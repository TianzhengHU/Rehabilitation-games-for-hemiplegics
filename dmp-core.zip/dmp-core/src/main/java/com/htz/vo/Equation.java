package com.htz.vo;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/31 4:08 PM
 * @Version 1.0
 */


public class Equation {
    private String pid;
    private String abbr;
    private double m;
    private double b;

    public Equation() {
    }

    public Equation(String pid, String abbr, double m, double b) {
        this.pid = pid;
        this.abbr = abbr;
        this.m = m;
        this.b = b;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getAbbr() {
        return abbr;
    }

    public void setAbbr(String abbr) {
        this.abbr = abbr;
    }

    public double getM() {
        return m;
    }

    public void setM(double m) {
        this.m = m;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }
}
