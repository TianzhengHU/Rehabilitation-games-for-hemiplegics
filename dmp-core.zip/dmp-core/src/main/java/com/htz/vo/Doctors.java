package com.htz.vo;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/15 9:32 AM
 * @Version 1.0
 */


public class Doctors {
    private Integer did;
    private String dname;
    private String dpassword;
    private Integer sex;
    private String email;
    private String mobile;

    public Doctors() {
    }

    public Doctors(Integer did, String dname, String dpassword, Integer sex, String email, String mobile) {
        this.did = did;
        this.dname = dname;
        this.dpassword = dpassword;
        this.sex = sex;
        this.email = email;
        this.mobile = mobile;
    }

    public Integer getDid() {
        return did;
    }

    public void setDid(Integer did) {
        this.did = did;
    }

    public String getDname() {
        return dname;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }

    public String getDpassword() {
        return dpassword;
    }

    public void setDpassword(String dpassword) {
        this.dpassword = dpassword;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
