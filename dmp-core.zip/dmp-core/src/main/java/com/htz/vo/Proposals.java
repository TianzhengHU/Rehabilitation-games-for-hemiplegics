package com.htz.vo;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/16 4:46 PM
 * @Version 1.0
 */


public class Proposals {
    private Integer proid;
    private String pname;
    private String pid;
    private Integer did;
    private String createdt;
    private String details;

    public Proposals() {
    }

    public Proposals(Integer proid, String pname, String pid, Integer did, String createdt, String details) {
        this.proid = proid;
        this.pname = pname;
        this.pid = pid;
        this.did = did;
        this.createdt = createdt;
        this.details = details;
    }

    public Integer getProid() {
        return proid;
    }

    public void setProid(Integer proid) {
        this.proid = proid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public Integer getDid() {
        return did;
    }

    public void setDid(Integer did) {
        this.did = did;
    }

    public String getCreatedt() {
        return createdt;
    }

    public void setCreatedt(String createdt) {
        this.createdt = createdt;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }
}
