package com.htz;

import org.jfree.chart.servlet.DisplayChart;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;

/**
 * description: dmp-core
 *
 * @Author Miracle Luna
 * @Date 2022/5/14 10:35 AM
 * @Version 1.0
 */

@SpringBootApplication
public class AppStarter {
    public static void main(String[] args) {
        SpringApplication.run(AppStarter.class);
    }
    @Bean
    public ServletRegistrationBean Servlet() {
        return new ServletRegistrationBean<>(new DisplayChart(),"/chart");
    }
}
