package com.htz.mapper;

import com.htz.vo.Datas;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/16 3:53 PM
 * @Version 1.0
 */

@Mapper
public interface DataMapper {

    @Select("select * from Datas")
    List<Datas> list();

    @Select("select * from Datas where pid=#{dataPid} ORDER BY DataId")
    List<Datas> getDataByPid(@Param("dataPid") String dataPid);
}
