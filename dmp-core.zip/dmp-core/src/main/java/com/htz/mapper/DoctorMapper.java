package com.htz.mapper;

import com.htz.vo.Doctors;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/15 9:29 AM
 * @Version 1.0
 */

@Mapper
public interface DoctorMapper {
    @Select("select * from Doctors")
    List<Doctors> list();

    @Delete("delete from Doctors where did=#{did}")
    void delete(@Param("did") Integer did);

    @Select("select * from Doctors where did=#{did}")
    Doctors getDoctorByDid(@Param("did") Integer did);
}

