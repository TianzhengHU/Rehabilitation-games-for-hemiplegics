package com.htz.mapper;

import com.htz.vo.Equation;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/31 4:57 PM
 * @Version 1.0
 */

@Mapper
public interface EquationMapper {
    @Select("select * from Equation where pid=#{pid}")
    List<Equation> getEquationsByPid(@Param("pid") String pid);
}
