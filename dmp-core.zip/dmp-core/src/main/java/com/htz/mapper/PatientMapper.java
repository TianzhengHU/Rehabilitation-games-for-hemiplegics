package com.htz.mapper;

import com.htz.vo.Patients;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/15 10:38 AM
 * @Version 1.0
 */

@Mapper
public interface PatientMapper {
    @Select("select * from Patients")
    List<Patients> list();
    @Select("select * from Patients where pid=#{pid}")
    Patients getPatientById(@Param("pid") String pid);

    @Insert("insert into Patients values(#{patient.pid},#{patient.pname},#{patient.sex},#{patient.age},#{patient.mobile},#{patient.password},null)")
    void add(@Param("patient") Patients patient);

    @Update("update patients set history=#{patients.history} where pid=#{patients.pid}")
    void update(@Param("patients") Patients patients);


}
