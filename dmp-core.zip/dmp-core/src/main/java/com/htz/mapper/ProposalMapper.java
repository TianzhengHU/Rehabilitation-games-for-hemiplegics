package com.htz.mapper;

import com.htz.vo.Proposals;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * description: dmp-core
 *
 * @Author htz
 * @Date 2022/5/17 3:56 PM
 * @Version 1.0
 */

@Mapper
public interface ProposalMapper {

    @Select("select * from Proposals")
    List<Proposals> list();

    @Select("select * from Proposals where pid=#{pid}")
    Proposals getProposalByPid(@Param("pid") String pid);

    @Insert("insert into Proposals values(null,#{proposals.pname},#{proposals.pid},#{proposals.did},#{proposals.createdt},#{proposals.details})")
    void add(@Param("proposals") Proposals proposals);


}
